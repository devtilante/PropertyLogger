$(document).ready(function(){
	
	$(window).scroll(function() {
		var scrollTop = $(window).scrollTop()
		if (scrollTop > 200) {
			$('nav.navbar').addClass('fix_bg')
		} else {
			$('nav.navbar').removeClass('fix_bg')
		}
	})
})